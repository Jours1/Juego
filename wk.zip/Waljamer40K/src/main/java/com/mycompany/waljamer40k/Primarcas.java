/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.waljamer40k;

/**
 *
 * @author Jours
 */
public  abstract class Primarcas {

int LionElJonson,Fulgrim,Perturabo,LemanRuss,RogalDorn,Sanguinius,Angron,Mortarion,Vulkan;  

    public Primarcas(int LionElJonson, int Fulgrim, int Perturabo, int LemanRuss, int RogalDorn, int Sanguinius, int Angron, int Mortarion, int Vulkan) {
        this.LionElJonson = LionElJonson;
        this.Fulgrim = Fulgrim;
        this.Perturabo = Perturabo;
        this.LemanRuss = LemanRuss;
        this.RogalDorn = RogalDorn;
        this.Sanguinius = Sanguinius;
        this.Angron = Angron;
        this.Mortarion = Mortarion;
        this.Vulkan = Vulkan;
    }

    public int getLionElJonson() {
        return LionElJonson;
    }

    public void setLionElJonson(int LionElJonson) {
        this.LionElJonson = LionElJonson;
    }

    public int getFulgrim() {
        return Fulgrim;
    }

    public void setFulgrim(int Fulgrim) {
        this.Fulgrim = Fulgrim;
    }

    public int getPerturabo() {
        return Perturabo;
    }

    public void setPerturabo(int Perturabo) {
        this.Perturabo = Perturabo;
    }

    public int getLemanRuss() {
        return LemanRuss;
    }

    public void setLemanRuss(int LemanRuss) {
        this.LemanRuss = LemanRuss;
    }

    public int getRogalDorn() {
        return RogalDorn;
    }

    public void setRogalDorn(int RogalDorn) {
        this.RogalDorn = RogalDorn;
    }

    public int getSanguinius() {
        return Sanguinius;
    }

    public void setSanguinius(int Sanguinius) {
        this.Sanguinius = Sanguinius;
    }

    public int getAngron() {
        return Angron;
    }

    public void setAngron(int Angron) {
        this.Angron = Angron;
    }

    public int getMortarion() {
        return Mortarion;
    }

    public void setMortarion(int Mortarion) {
        this.Mortarion = Mortarion;
    }

    public int getVulkan() {
        return Vulkan;
    }

    public void setVulkan(int Vulkan) {
        this.Vulkan = Vulkan;
    }
   
    int suma=LionElJonson+Fulgrim+Perturabo+LemanRuss+RogalDorn+Sanguinius+Angron+Mortarion+Vulkan;
    public void LionElJonson1(){
        if(LionElJonson==1 && suma==1){
            System.out.println("                            Ángeles Oscuros");
            System.out.println("Desde la fundación de su Legión en el nacimiento del Imperio, los Marines Espaciales de ");
            System.out.println("los Ángeles Oscuros han sido temidos por sus enemigos y reciben la admiración de aquellos ");
            System.out.println("a quienes protegen. Obstinados e incansables en la batalla, siempre vigilantes y entusiastas ");
            System.out.println("en la persecución de sus deberes, los Ángeles Oscuros están considerados unos de los más ");
            System.out.println("fieles siervos del Emperador. Sin embargo, no fue siempre así. Durante diez milenios los Ángeles ");
            System.out.println("Oscuros han guardado un siniestro secreto, un acto tan terrible y vergonzoso que desafía todo lo ");
            System.out.println("que más quieren los Ángeles Oscuros, y que podría quizás traerles la condenación eterna.");
            System.out.println("");
        }
        }
    public void Fulgrim1(){
        if(Fulgrim==1 && suma==1){
            System.out.println("                         Hijos del Emperador ");
            System.out.println("Los Hijos del Emperador (Emperor's Children en inglés) fueron la III Legión de Marines");
            System.out.println("Espaciales que el Emperador creó para su Gran Cruzada. Su Primarca es Fulgrim, y su mundo");
            System.out.println("natal era Chemos. Durante la Herejía de Horus se unieron al Señor de la Guerra Horus contra el");
            System.out.println("Imperio, y cayeron en el culto a Slaanesh, convirtiéndose en psicópatas hedonistas que");
            System.out.println("viven por experimentar nuevos excesos.");
        }
        }
    public void Perturabo1(){
        if(Perturabo==1&& suma==1){
            System.out.println("                       Guerreros de Hierro");
            System.out.println("Los Guerreros de Hierro tienen corazones fríos y amargos. Para ellos la");
            System.out.println("guerra es el traqueteo del ábaco del contable; toda la sangre derramada y las");
            System.out.println("vidas perdidas, las murallas derribadas y los enemigos destruidos no son para ellos");
            System.out.println("más que monedas añadidas a las arcas de la muerte. Los beneficios y las");
            System.out.println("pérdidas de cada batalla son su pan, la aritmética de la masacre es su vino, y con");
            System.out.println("ellos sirven un festín ceniciento, que a pesar de todo no disfrutan. Hay muchos");
            System.out.println("que miran a las Legiones del Emperador y ven en la estirpe de Mortarion la");
            System.out.println("encarnación del antiguo espíritu de la muerte, pero unos pocos sabios miran los");
            System.out.println("cementerios en que los hijos sin rostro de Perturabo convierten los mundos que");
            System.out.println("pisan con una eficiencia tan calculada, y disienten");
            System.out.println("");                   
        }
        } 
       public void LemanRuss1(){
           if(LemanRuss==1&& suma==1){
           System.out.println("                            Lobos Espaciales");
           System.out.println("La gente cree que los Astartes de la VI son unos simples salvajes, pero tú has");
           System.out.println("pasado el tiempo suficiente entre nosotros para saber que eso no es");
           System.out.println("verdad. Luchamos con inteligencia. No nos limitamos a lanzarnos a la carga,");
           System.out.println("aunque parezca que eso es lo que hacemos. Siempre utilizamos una");
           System.out.println("inteligencia táctica impecable. Aprovechamos cualquier grieta en el");
           System.out.println("enemigo, cualquier debilidad que tenga. Somos implacables, no somos estúpidos");
           System.out.println("");
        }
        } 
        public void RogalDorn1(){
           if(RogalDorn==1&& suma==1){
           System.out.println("                            Puños Imperiales");
           System.out.println("No busquéis amabilidad en nosotros. No busquéis esperanza en nosotros. No");
           System.out.println("somos los hijos amables de esta nueva era. Somos las rocas de sus cimientos. Si");
           System.out.println("deseáis esperanza, mirad lo que creamos. Si deseáis amabilidad, mirad a los que");
           System.out.println("vendrán después de nosotros.");
           System.out.println("");
        }  
        }
        public void Sanguinius1(){
            if(Sanguinius==1&& suma==1){
           System.out.println("                             Ángeles Sangrientos");
           System.out.println("Se llaman a sí mismos ángeles, estos despojos de un millar de infiernos que se");
           System.out.println("han visto elevados y dotados de brillantes armaduras, relucientes espadas y");
           System.out.println("máscaras de forma bella y elegante. Y sin embargo, me pregunto: ¿han llevado");
           System.out.println("puestas esas máscaras tanto tiempo que se han olvidado de lo que aguarda bajo");
           System.out.println("ellas, esa faceta monstruosa que ansía ser liberada?");
           System.out.println("");
        }
        }
        public void Vulkan1(){
         if(Vulkan==1&& suma==1){
          System.out.println("                               Salamandras");
          System.out.println("La crisis es una verdad, esto es evidente por sí mismo y no debe ser objeto de");
          System.out.println("burlas. Es algo tan claro para el herrero como lo es para el arquitecto: ninguna");
          System.out.println("espada puede ser considerada adecuada hasta que se ha encontrado con otra en");
          System.out.println("la batalla, ni ninguna torre puede ser considerada fuerte hasta que ha");
          System.out.println("afrontado una tormenta. Lo mismo ocurre con los hombres: solo en el terror, en la");
          System.out.println("terrible adversidad, en la oscuridad de la destrucción y la desesperación podrás");
          System.out.println("ver lo que son de verdad.");
          System.out.println("");
        }   
        }
        
    
     public abstract float linaje();
    void SUMA(){
        if(suma>1){
            System.err.println("Solo se pude escojer ha un primarca");
        }
    }
}
