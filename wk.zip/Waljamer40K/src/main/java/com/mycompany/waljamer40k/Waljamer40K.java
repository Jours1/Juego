/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.waljamer40k;

/**
 *
 * @author abund
 */
public class Waljamer40K {
int ArañaPlusDaño=6/5,ArañaPlusDefensa=10/13, PlusDañoAsaltoLijero=5/4, PlusDañoAsaltoPesado=6/5;

    public static void main(String[] args) {
   
   
//---------------------------------------------------------------------------------------------------------------     
// Spase marines  
   /* SpaseMarines p1=new SpaseMarines(1, 1, 1, 1, 1, 1);
     p1.prorrogó();
     p1.AsaltoLijero();
     p1.AsaltoPesado();
     p1.Dretnout();
     p1.Siqico();
     p1.Veiculos();
     p1.FichasSpaseMarines();   */
//---------------------------------------------------------------------------------------------------------------
// necrones 
//---------------------------------------------------------------------------------------------------------------
  /* Necrones p2=new Necrones(1, 1, 1, 1, 1); // fata reconficurdard las arañas y los otros blinados 
    p2.ArañaCronoptica();
    p2.Desollador1();
    p2.TrasformadoAntiguo1();
    p2.getEspectrocronoscopico();
    p2.FichasNecrones();*/
//---------------------------------------------------------------------------------------------------------------
//primarcas
//---------------------------------------------------------------------------------------------------------------
   /*Primarcas z=new Primarcas(1, 1, 1, 1, 1, 1, 1, 1, 1);
     z.Fulgrim1();
     z.LemanRuss1();
     z.LionElJonson1();
     z.Perturabo1();
     z.RogalDorn1();
     z.Sanguinius1();
     z.Vulkan1();
     z.SUMA();*/
//---------------------------------------------------------------------------------------------------------------
//Necones calses opjetos
//---------------------------------------------------------------------------------------------------------------
    /*Desolladores       p1_1=new Desolladores      (0, 0, 0, 0, "n");
     TrasformadoAntiguo p1_2=new TrasformadoAntiguo(0, 0, 0, 0, "n");
     EspectroCronoptica p1_3=new EspectroCronoptica(0, 0, 0, 0, "n");
     ArañaCronoptic     p1_4=new ArañaCronoptic    (0, 0, 0, 0, "n");
     
     p1_1.AtaqueDesollador        ("desollador"          , 0, 0, 0, 0, 0, 0, 0,    p1_1);
     p1_2.AtaqueTrasformadoAntiguo("Trasformado antiguo" , 0, 0, 0, 0, 0, 0, 0,    p1_2);
     p1_3.AtaqueEspectroCronoptica("Espectro Cronocopico", 0, 0, 0, 0, 0, 0, 0, 0, p1_3);
     p1_4.AtaqueArañaCronoptica   ("Araña macrocopico"   , 0, 0, 0, 0, 0, 0, 0, 0, p1_4);*/
//---------------------------------------------------------------------------------------------------------------     
// SpaceMarines calses opjetos
//---------------------------------------------------------------------------------------------------------------    
    /* AsaltoLijero       p2_1=new AsaltoLijero      (0, 0, 0, 0, "n");
     AsaltoPesado       P2_2=new AsaltoPesado      (0, 0, 0, 0, "n");
     Drednot            p2_3=new Drednot           (0, 0, 0, 0, "n");
     Blindados          P2_4=new Blindados         (0, 0, 0, 0, "n");
     
    
     p2_1.AtaqueAsaltolijero    ("Asalto lijero", 0, 0, 0, 0, 0, 0, 0,    p2_1);
     P2_2.AtaqueAsaltoPesado    ("Asalto Pesado", 0, 0, 0, 0, 0, 0, 0,    p2_1);
     p2_3.Drednout              ("Drednot",       0, 0, 0, 0, 0, 0, 0, 0, p2_3);
     p2_3.vehículo              ("tanque",        0, 0, 0, 0, 0, 0, 0, 0, p2_1);*/
     
//----------------------------------------------------------------------------------------------------------------- 
     
          
     ArañaCronoptic p1=new ArañaCronoptic    (100, 70, 100, 100, "sombra");
     AsaltoLijero   p2=new AsaltoLijero      (150, 20, 100, 100, "Mitic");
     p1.AtaqueArañaCronoptica     (0, 0, 0, 0, p2);
     p2.AtaqueAsaltolijero        (0, 0, p1);
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      }//yamado
      
      
    
    

} // final